# Spec
Deferred integration assessment.
